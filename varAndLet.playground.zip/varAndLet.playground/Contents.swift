import UIKit

var greeting = "Hello, playground"
 
print(greeting)

let pi = 314

print(pi)

var isim = "Sinan"

print("hello , \(isim)")

var yaslar = [3, 5, 7, 45, 75]

var isimler = ["ali", "veli", "alra"]

print("\(isimler[0]) \(yaslar[2]) yasindadir.")


